var GameModel = Backbone.Model.extend({
	defaults: {
		current_level: 0
	}
});