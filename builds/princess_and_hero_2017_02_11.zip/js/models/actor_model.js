var ActorModel = Backbone.Model.extend({
	defaults: {
		hp: "3",
  		damage: "1",
  		keys: "0",
	}
});